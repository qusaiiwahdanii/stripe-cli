// Copyright (c) Martin Ridgers
// License: http://opensource.org/licenses/MIT

#pragma once

struct hooked_stat
{
    int st_size;
    int st_mode;
};
