-- Copyright (c) Martin Ridgers
-- License: http://opensource.org/licenses/MIT

return {
    name = "lib",
    files = {
        "generator.lua",
        "arguments.lua",
        "debugger.lua",
    }
}
