// Copyright (c) Martin Ridgers
// License: http://opensource.org/licenses/MIT

#pragma once

#include <core/base.h>

#include "clatch.h"

#include <Windows.h>
