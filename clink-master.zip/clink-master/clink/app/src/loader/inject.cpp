// Copyright (c) Martin Ridgers
// License: http://opensource.org/licenses/MIT

#include "pch.h"
#include "utils/app_context.h"
#include "version.h"

#include <core/base.h>
#include <core/log.h>
#include <core/os.h>
#include <core/path.h>
#include <core/str.h>
#include <core/str_hash.h>
#include <getopt.h>
#include <process/process.h>
#include <process/vm.h>

//------------------------------------------------------------------------------
bool __stdcall  initialise_clink(const AppContext::Desc&);
void            puts_help(const char**, int32);

//------------------------------------------------------------------------------
static void copy_dll(StrBase& dll_path)
{
    Str<280> target_path;
    {
        Wstr<280> dir;
        if (SHGetFolderPathW(0, CSIDL_LOCAL_APPDATA, nullptr, 0, dir.data()) == S_OK)
        {
            target_path = dir.c_str();
        }
    }

    if (target_path.empty() && !os::get_temp_dir(target_path))
    {
        LOG("Unable to get temp path");
        return;
    }

    target_path << "/clink/dll_cache/" CLINK_VERSION_STR;

    Str<12, false> path_salt;
    path_salt.format("_%08x", str_hash(dll_path.c_str()));
    target_path << path_salt;

    os::make_dir(target_path.c_str());
    if (os::get_path_type(target_path.c_str()) != os::path_type_dir)
    {
        LOG("Unable to create path '%s'", target_path.c_str());
        return;
    }

    target_path << "/" CLINK_DLL;

#if !defined(CLINK_FINAL)
    // The DLL id only changes on a commit-premake cycle. During development this
    // doesn't work so well so we'll force it through. TODO: check timestamps
    const bool always = true;
#else
    const bool always = false;
#endif

    // Write out origin path to a file so we can backtrack from the cached DLL.
    int32 target_length = target_path.length();
    target_path << ".origin";
    if (always || os::get_path_type(target_path.c_str()) != os::path_type_file)
    {
        Wstr<280> wcopy_path(target_path.c_str());
        HANDLE out = CreateFileW(wcopy_path.c_str(), GENERIC_WRITE, 0, nullptr,
            CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (out != INVALID_HANDLE_VALUE)
        {
            DWORD written;
            WriteFile(out, dll_path.c_str(), dll_path.length(), &written, nullptr);
            CloseHandle(out);
        }
    }

    if (os::get_path_type(target_path.c_str()) != os::path_type_file)
    {
        LOG("Failed to create origin file at '%s'.", target_path.c_str());
        return;
    }

    target_path.truncate(target_length);

    // Copy the DLL.
    if (always || os::get_path_type(target_path.c_str()) != os::path_type_file)
        os::copy(dll_path.c_str(), target_path.c_str());

    if (os::get_path_type(target_path.c_str()) != os::path_type_file)
    {
        LOG("Failed to copy DLL to '%s'", target_path.c_str());
        return;
    }

    dll_path = target_path.c_str();
}

//------------------------------------------------------------------------------
static int32 check_dll_version(const char* clink_dll)
{
    char buffer[1024];
    if (GetFileVersionInfo(clink_dll, 0, sizeof(buffer), buffer) != TRUE)
        return 0;

    VS_FIXEDFILEINFO* file_info;
    if (VerQueryValue(buffer, "\\", (void**)&file_info, nullptr) != TRUE)
        return 0;

    LOG("DLL version: %08x %08x",
        file_info->dwFileVersionMS,
        file_info->dwFileVersionLS
    );

    int32 error = 0;
    error = (HIWORD(file_info->dwFileVersionMS) != CLINK_VERSION_MAJOR);
    error = (LOWORD(file_info->dwFileVersionMS) != CLINK_VERSION_MINOR);
    error = (HIWORD(file_info->dwFileVersionLS) != CLINK_VERSION_PATCH);

    return !error;
}

//------------------------------------------------------------------------------
static void* inject_dll(DWORD target_pid)
{
    // Get path to clink's DLL that we'll inject.
    Str<280> dll_path;
    Process().get_file_name(dll_path);
    path::get_directory(dll_path);
    path::append(dll_path, CLINK_DLL);

    copy_dll(dll_path);

    // Reset log file, start logging!
#if 0
    /* GetVersionEx() is deprecated and the VerifyVersioninfo() replacement
     * is bonkers.
     */
    SYSTEM_INFO sys_info;
    GetSystemInfo(&sys_info);

    OSVERSIONINFOEX osvi;
    osvi.dwOSVersionInfoSize = sizeof(osvi);
    GetVersionEx((OSVERSIONINFO*)&osvi);

    LOG("System: ver=%d.%d %d.%d Arch=%d cpus=%d cpu_type=%d page_size=%d",
        osvi.dwMajorVersion,
        osvi.dwMinorVersion,
        osvi.wServicePackMajor,
        osvi.wServicePackMinor,
        sys_info.wProcessorArchitecture,
        sys_info.dwNumberOfProcessors,
        sys_info.dwProcessorType,
        sys_info.dwPageSize
    );
#endif
    LOG("Version: %s", CLINK_VERSION_STR);
    LOG("Arch: x%s", AS_STR(ARCHITECTURE));
    LOG("DLL: %s", dll_path.c_str());

    LOG("Parent pid: %d", target_pid);

    // Check Dll's version.
    if (!check_dll_version(dll_path.c_str()))
    {
        ERR("DLL failed version check.");
        return 0;
    }

    // Inject Clink DLL.
    Process cmd_process(target_pid);
    return cmd_process.inject_module(dll_path.c_str());
}

//------------------------------------------------------------------------------
static bool is_clink_present(DWORD target_pid)
{
    HANDLE th32 = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, target_pid);
    if (th32 == INVALID_HANDLE_VALUE)
    {
        LOG("Failed to snapshot module state.");
        return false;
    }

    bool ret = false;

    MODULEENTRY32 module_entry = { sizeof(module_entry) };
    BOOL ok = Module32First(th32, &module_entry);
    while (ok != FALSE)
    {
        if (_strnicmp(module_entry.szModule, "clink_", 6) == 0)
        {
            LOG("Clink already installed in process.");
            ret = true;
            break;
        }

        ok = Module32Next(th32, &module_entry);
    }

    CloseHandle(th32);
    return ret;
}

//------------------------------------------------------------------------------
static DWORD find_inject_target()
{
    Str<512, false> buffer;
    for (int32 pid = Process().get_parent_pid(); pid;)
    {
        Process process(pid);
        process.get_file_name(buffer);
        const char* name = path::get_name(buffer.c_str());
        if (_stricmp(name, "cmd.exe") == 0)
            return pid;

        pid = process.get_parent_pid();
    }

    return 0;
}

//------------------------------------------------------------------------------
void get_profile_path(const char* in, StrBase& out)
{
    if (in[0] == '~' && (in[1] == '\\' || in[1] == '/'))
    {
        wchar_t dir[MAX_PATH];
        if (SHGetFolderPathW(0, CSIDL_LOCAL_APPDATA, nullptr, 0, dir) == S_OK)
        {
            out = dir;
            out << (in + 1);
            return;
        }
    }

    os::get_current_dir(out);
    path::append(out, in);
    path::normalise(out);
}

//------------------------------------------------------------------------------
int32 inject(int32 argc, char** argv)
{
    struct option options[] = {
        { "profile",     required_argument,  nullptr, 'p' },
        { "quiet",       no_argument,        nullptr, 'q' },
        { "pid",         required_argument,  nullptr, 'd' },
        { "nolog",       no_argument,        nullptr, 'l' },
        { "autorun",     no_argument,        nullptr, '_' },
        { "help",        no_argument,        nullptr, 'h' },
        { nullptr, 0, nullptr, 0 }
    };

    const char* help[] = {
        "-p, --profile <path>", "Specifies and alternative path for profile data.",
        "-q, --quiet",          "Suppress copyright output.",
        "-d, --pid <pid>",      "Inject into the process specified by <pid>.",
        "-l, --nolog",          "Disable file logging.",
        "-h, --help",           "Shows this help text.",
    };

    extern const char* g_clink_header;

    // Parse arguments
    DWORD target_pid = 0;
    AppContext::Desc app_desc;
    int32 i;
    int32 ret = false;
    while ((i = getopt_long(argc, argv, "nalqhp:d:", options, nullptr)) != -1)
    {
        switch (i)
        {
        case 'p':
            {
                StrBase state_dir(app_desc.state_dir);
                get_profile_path(optarg, state_dir);
            }
            break;

        case 'q': app_desc.quiet = true;        break;
        case 'd': target_pid = atoi(optarg);    break;
        case '_': ret = true;                   break;

        case 'l':
            app_desc.log = false;
            break;

        case '?':
            return ret;

        case 'h':
        default:
            puts(g_clink_header);
            puts_help(help, sizeof_array(help));
            return ret;
        }
    }

    // Restart the log file on every inject.
    Str<256> log_path;
    AppContext::get()->get_log_path(log_path);
    unlink(log_path.c_str());

    // Unless a target pid was specified on the command line search for a
    // compatible parent process.
    if (target_pid == 0)
    {
        if (!(target_pid = find_inject_target()))
        {
            LOG("Failed to find parent pid.");
            return ret;
        }
    }

    // Check to see if clink is already installed.
    if (is_clink_present(target_pid))
        return ret;

    // Inject Clink's DLL
    void* remote_dll_base = inject_dll(target_pid);
    if (remote_dll_base == nullptr)
        return ret;

    // Remotely call Clink's initialisation function.
    void* our_dll_base = Vm().get_alloc_base("");
    uintptr_t init_func = uintptr_t(remote_dll_base);
    init_func += uintptr_t(initialise_clink) - uintptr_t(our_dll_base);
    ret |= (Process(target_pid).remote_call((void*)init_func, app_desc) != nullptr);

    return ret;
}
