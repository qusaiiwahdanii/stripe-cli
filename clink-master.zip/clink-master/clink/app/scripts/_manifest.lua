return {
    name = "app",
    files = {
        "cmd.lua",
        "dir.lua",
        "env.lua",
        "exec.lua",
        "prompt.lua",
        "self.lua",
        "set.lua",
    }
}
